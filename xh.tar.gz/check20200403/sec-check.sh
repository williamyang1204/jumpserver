#!/bin/bash 
# Starting
echo 
echo "####################################"
echo "Starting from"
    date
echo "####################################"
echo 
echo "************************************"
echo "1. 文件系统安全检查"
echo "************************************"
echo 
echo "1.1 不加载无用的Filesystem模块"
echo "lsmod |grep 'cramfs|freevxfs|jfsfs2|hfs|squashfs|udf|vfat'"
    lsmod |grep 'cramfs|freevxfs|jfsfs2|hfs|squashfs|udf|vfat'
echo 
echo "------------------------------------"
echo 
echo "1.2 检查tmpfs的运行权限"
echo "mount | grep /dev/shm"
    mount | grep /dev/shm
echo 
echo "------------------------------------"
echo 
echo "1.3 autofs已关闭"
echo "systemctl is-enabled autofs"
    systemctl is-enabled autofs
echo 
echo "------------------------------------"
echo 
echo "************************************"
echo "2. 安装软件源检查"
echo "************************************"
echo 
echo "2.1 GPG验证是否开启"
echo "grep ^gpgcheck /etc/yum.conf"
    grep ^gpgcheck /etc/yum.conf
echo 
echo "grep ^gpgcheck /etc/yum.repos.d/*"
    grep ^gpgcheck /etc/yum.repos.d/*
echo 
echo "************************************"
echo "3. boot安全性检查"
echo "************************************"
echo 
echo "3.1 grub 文件权限"
echo "stat /boot/grub2/grub.cfg|grep Uid"
    stat /boot/grub2/grub.cfg|grep Uid
echo 
echo "************************************"
echo "4.系统文件属性检查"
echo "************************************"
echo
echo "4.1 检查系统文件属性为root:root,且只有root有写的权限600/644 "
echo "stat /etc/passwd /etc/shadow /etc/group /etc/hosts /etc/hosts.allow /etc/hosts.deny /etc/crontab /etc/ssh/sshd_config |grep Uid"
    stat /etc/passwd /etc/shadow /etc/group /etc/hosts /etc/hosts.allow /etc/hosts.deny /etc/crontab /etc/ssh/sshd_config |grep Uid
echo 
echo "------------------------------------"
echo 
echo "4.2 检查所有other可以写目录，设置了sticky bit"
echo "find / -xdev -mount -type d \( -perm -0002 -a ! -perm -1000 \)"
    find / -xdev -mount -type d \( -perm -0002 -a ! -perm -1000 \)
echo 
echo "------------------------------------"
echo 
echo "4.3 检查root用户的PATH包含目录，other没有写的权限"
echo "find $(echo $PATH | tr ':' ' ')  -type d \( -perm -0777 \)"
    find $(echo $PATH | tr ':' ' ')  -type d \( -perm -0777 \)
echo 
echo "************************************"
echo "5.检查用户管理"
echo "************************************"
echo
echo "5.1 检查无密码的用户"
echo "awk -F: '($2 == "") {print}' /etc/shadow"
    awk -F: '($2 == "") {print}' /etc/shadow
echo 
echo "------------------------------------"
echo
echo "5.2 检查root是唯一的uid为0的用户"
echo "cat /etc/passwd | awk -F: '($3 == 0) { print $1 }'|grep -v '^root$' "
    cat /etc/passwd | awk -F: '($3 == 0) { print $1 }'|grep -v '^root$' 
echo 
echo "------------------------------------"
echo
echo "5.3 检查可以登录的用户"
echo "egrep -v 'nologin|shutdown|sync|halt' /etc/passwd "
    egrep -v 'nologin|shutdown|sync|halt' /etc/passwd
echo  
echo "************************************"
echo "6.Apache/tomcat 检查"
echo "************************************"
echo
echo "6.1 tomcat缺省的Sample文件已删除"
echo " ls -l  /opt/apache-tomcat/webapps"
    ls -l  /opt/apache-tomcat/webapps
echo 
echo "------------------------------------"
echo
echo "6.2 检查只配置了idp服务的Connector"
echo "grep "Connector" /opt/apache-tomcat/conf/server.xml"
    grep "Connector" /opt/apache-tomcat/conf/server.xml
echo 
echo "------------------------------------"
echo
echo "6.3 确认开启SSL并配置正常"
echo "egrep 'Connector|SSLEnabled|scheme|sslProtocol' /opt/apache-tomcat/conf/server.xml"
    egrep 'Connector|SSLEnabled|scheme|sslProtocol' /opt/apache-tomcat/conf/server.xml
echo  
echo "####################################"
echo "End at"
    date
echo "####################################"
# END
