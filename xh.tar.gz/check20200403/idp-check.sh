#!/bin/bash 
# Starting
echo 
echo "####################################"
echo "Starting from"
date
echo "####################################"
echo 
echo "/opt/shibboleth-idp/conf/attribute-filter.xml"
echo "------------------------------------"
    cat /opt/shibboleth-idp/conf/attribute-filter.xml
echo 
echo "------------------------------------"
echo 
echo 
echo "/opt/shibboleth-idp/conf/attribute-resolver.xml"
echo "------------------------------------"
    cat /opt/shibboleth-idp/conf/attribute-resolver.xml
echo 
echo "------------------------------------"
echo 
echo 
echo "/opt/shibboleth-idp/conf/ldap.properties"
echo "------------------------------------"
    cat /opt/shibboleth-idp/conf/ldap.properties
echo 
echo "------------------------------------"
echo 
echo 
echo "/opt/shibboleth-idp/conf/metadata-providers.xml"
echo "------------------------------------"
    cat /opt/shibboleth-idp/conf/metadata-providers.xml
echo 
echo "------------------------------------"
echo 
echo 
echo "/opt/shibboleth-idp/conf/idp.properties"
echo "------------------------------------"
    cat /opt/shibboleth-idp/conf/idp.properties
echo 
echo "------------------------------------"
echo 
echo 
echo "/opt/apache-tomcat/conf/server.xml"
echo "------------------------------------"
    cat /opt/apache-tomcat/conf/server.xml
echo 
echo "------------------------------------"
echo 
echo "####################################"
echo "End at"
date
echo "####################################"
# END
