#!/bin/bash
tt=`date "+%Y-%m-%d"`
echo "Starting ..."
sh ./sys-check.sh  > Sys-Checklog"-""$tt.log" 2>&1
sh ./idp-check.sh  > Idp-Checklog"-""$tt.log" 2>&1
sh ./sec-check.sh  > Sec-Checklog"-""$tt.log" 2>&1
echo "Finished"
