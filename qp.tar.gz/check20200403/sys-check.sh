﻿#!/bin/bash 
# Starting
echo 
echo "####################################"
echo "Starting from"
    date
echo "####################################"
echo 
echo "************************************"
echo "1. 系统配置配置检查"
echo "************************************"
echo 
echo "1.1 检查系统版本"
echo "uname -r"
    uname -r
echo 
echo "------------------------------------"
echo 
echo "1.2 检查服务器名"
echo "hostname"
     hostname
echo 
echo "------------------------------------"
echo 
echo "1.3 检查服务器域名"
echo "domainname"
    domainname
echo 
echo "------------------------------------"
echo 
echo "1.4 检查服务器时间"
echo "date"
    date
echo 
echo "------------------------------------"
echo 
echo "1.5 检查时间服务"
echo "ntpstat"
    ntpstat
echo 
echo 
echo "************************************"
echo "2. 网络系统配置配置检查"
echo "************************************"
echo
echo "2.1 检查IP配置"
echo "ip addr"
    ip addr
echo 
echo "------------------------------------"
echo 
echo "2.2 检查网络路由"
echo "netstat -nr"
    netstat -nr
echo 
echo "------------------------------------"
echo 
echo "2.3 检查SELINUX状态"
echo "sestatus -v"
    sestatus -v
echo 
echo "------------------------------------"
echo 
echo "2.4 检查防火墙服务"
echo "systemctl status firewalld"
    systemctl status firewalld
echo 
echo "------------------------------------"
echo 
echo "2.4.1 检查防火墙端口策略"
echo "firewall-cmd  --list-ports"
    firewall-cmd  --list-ports
echo 
echo "------------------------------------"
echo 
echo "************************************"
echo "3.系统运行状态检查"
echo "------------------------------------"
echo 
echo "3.1 检查服务器运行时间和负载"
echo "uptime"
    uptime
echo 
echo "------------------------------------"
echo 
echo "3.2 检查服务器CPU配置"
echo "cat /proc/cpuinfo|grep cores"
    cat /proc/cpuinfo|grep cores
echo 
echo "------------------------------------"
echo 
echo "3.3 检查CPU负载"
echo "mpstat -u 1 1"
    mpstat -u 1 1
echo 
echo "------------------------------------"
echo 
echo "3.4 检查文件系统"
echo "df -h"
    df -h
echo 
echo "------------------------------------"
echo 
echo "3.5 检查内存"
echo "free -h"
    free -h
echo 
echo "------------------------------------"
echo 
echo "3.6 检查http/https 端口监听"
echo "netstat -lt|grep http"
    netstat -lt|grep http
echo 
echo "------------------------------------"
echo 
echo "3.7 检查磁盘IO负载"
echo "iostat -x 1 2"
    iostat -x 1 2
echo 
echo "************************************"
echo "4. 系统日志检查"
echo "************************************"
echo 
echo "4.1 检查系统日志文件状态"
echo "ls -l /var/log/messages*"
    ls -l /var/log/messages
echo 
echo "------------------------------------"
echo 
echo "4.2 检查日志文件总的error"
echo "grep -i error /var/log/messages*"
    grep -i error /var/log/messages
echo 
echo "------------------------------------"
echo 
echo "4.3 检查日志文件的fail"
echo "grep -i fail /var/log/messages*"
    grep -i fail /var/log/messages
echo 
echo "************************************"
echo "5. IDP服务检查"
echo "************************************"
echo 
echo "5.1 检查IDP日志文件状态"
echo "ls -l /opt/shibboleth-idp/logs/idp-process.log"
    ls -l /opt/shibboleth-idp/logs/idp-process.log
echo 
echo "------------------------------------"
echo 
echo "5.2 检查IDP日志文件总的error"
echo "grep -i error /opt/shibboleth-idp/logs/idp-process.log"
    grep -i error /opt/shibboleth-idp/logs/idp-process.log
echo 
echo "------------------------------------"
echo 
echo "5.3 检查IDP日志文件的fail"
echo "grep -i fail /opt/shibboleth-idp/logs/idp-process.log"
    grep -i fail /opt/shibboleth-idp/logs/idp-process.log
echo 
echo "------------------------------------"
echo 
echo "5.4 检查IDP服务状态"
echo "/opt/shibboleth-idp/bin/status.sh"
    /opt/shibboleth-idp/bin/status.sh
echo 
echo 
echo "####################################"
echo "End at"
    date
echo "####################################"
# END
